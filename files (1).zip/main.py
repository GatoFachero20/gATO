from gui.guide import GuideApp
from gui.stats_viewer import StatsViewerApp
import tkinter as tk

def main():
    root = tk.Tk()
    root.title("Left 4 Dead 2 - App Interactiva")
    
    # Crear botones para navegar entre la Guía y el Inspector de Estadísticas
    def open_guide():
        GuideApp(root)
    
    def open_stats_viewer():
        StatsViewerApp(root)
    
    tk.Label(root, text="Bienvenido a la App de Left 4 Dead 2", font=("Arial", 16)).pack(pady=10)
    tk.Button(root, text="Guía Interactiva", command=open_guide, width=20, height=2).pack(pady=5)
    tk.Button(root, text="Inspector de Estadísticas", command=open_stats_viewer, width=20, height=2).pack(pady=5)
    
    root.mainloop()

if __name__ == '__main__':
    main()