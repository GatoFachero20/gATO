import tkinter as tk
import pandas as pd
import matplotlib.pyplot as plt

class StatsViewerApp:
    def __init__(self, root):
        self.window = tk.Toplevel(root)
        self.window.title("Inspector de Estadísticas")
        
        tk.Label(self.window, text="Inspector de Estadísticas", font=("Arial", 14)).pack(pady=10)
        tk.Button(self.window, text="Cargar Estadísticas", command=self.load_stats).pack(pady=5)
    
    def load_stats(self):
        try:
            stats = pd.read_csv("data/stats.csv")
            plt.figure(figsize=(8, 5))
            stats.plot(kind="bar", x="Partida", y="Daño Infligido")
            plt.title("Daño Infligido por Partida")
            plt.show()
        except FileNotFoundError:
            tk.Label(self.window, text="Error: No se encontró el archivo de estadísticas.").pack(pady=5)