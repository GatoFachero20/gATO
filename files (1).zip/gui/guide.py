import tkinter as tk
import json

class GuideApp:
    def __init__(self, root):
        self.window = tk.Toplevel(root)
        self.window.title("Guía Interactiva")
        
        tk.Label(self.window, text="Guía de Left 4 Dead 2", font=("Arial", 14)).pack(pady=10)
        
        self.text = tk.Text(self.window, wrap=tk.WORD, width=50, height=20)
        self.text.pack(pady=10)
        
        self.load_guide()
    
    def load_guide(self):
        try:
            with open("data/guide.json", "r", encoding="utf-8") as file:
                guide_data = json.load(file)
                for section, content in guide_data.items():
                    self.text.insert(tk.END, f"=== {section.upper()} ===\n{content}\n\n")
        except FileNotFoundError:
            self.text.insert(tk.END, "Error: No se encontró el archivo de guía.")